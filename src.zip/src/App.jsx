import "./App.css";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Navbar from "./Component/pages/Home/Navbar";
import Home from "./Component/pages/Home/HomeScreen";
import NotFound from "./Component/pages/Home/NotFound";

function App() {
  return (
    <div className="App">
      <Router>
        <div>
        <Navbar />        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        </div>
      </Router>
    </div>
  );
}

export default App;
