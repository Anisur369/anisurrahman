import { Link } from "react-scroll";

export default function NotFound(){
    return (
        <div>
            <h1>404 - Page Not Found</h1>
            <p>The page you&apos;re looking for doesn&apos;t exist.</p>
            <Link to="/">Back to Homepage</Link>
        </div>
    )
}