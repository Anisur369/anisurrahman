export default function AboutMe() {
    return (
      <section id="AboutMe" className="about--section">
        <div className="about--section--img">
          <img src="../../../../src/assets/images/hero-section-image.png" alt="About Me" />
        </div>
        <div className="hero--section--content--box about--section--box">
          <div className="hero--section--content">
            <p className="section-title">About</p>
            <h1 className="skills-section-heading">About Me</h1>
            <p className="hero-section-description">
            Professional <b>Front-end</b> and <b>Back-end</b> developer: I am proficient in HTML, CSS, Tailwind CSS, and JavaScript, which enables me to create attractive and responsive web interfaces. My in-depth knowledge with React and back-end skills in Node.js empowers me to build complete web applications.
            </p>
            <p className="hero-section-description">
              A full-stack developer helps build and maintain both the front-end and back-end of a website. Learn about full-stack payroll integration.
            </p>
          </div>
        </div>
      </section>
    );
  }