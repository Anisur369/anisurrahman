export default function HeroSection(){
    return (
        <div>
            <section id="heroSection" className="hero-section">
                <div className="hero-section-content-box">
                    <div className="hero-section-content">
                        <p className="section-title">Hey, I&apos;m Anisur Rahman</p>
                        <h1 className="hero-section-title">
                            <span className="hero-section-title-color">Full Stack</span>{" "}
                            <br/>
                            Developer &amp; Designer
                        </h1>
                        <p className="hero-section-description">
                        Professional <b>Front-end</b> and <b>Back-end</b> developer: I am proficient in HTML, CSS, Tailwind CSS, and JavaScript, which enables me to create attractive and responsive web interfaces. My in-depth knowledge with React and back-end skills in Node.js empowers me to build complete web applications.
                        </p>                        
                    </div>
                    <button className="btn btn-primary">Learn More</button>
                </div>
                <div className="hero-section-img">
                    <div className="hero-section-solar-img">
                        <div className="wormHole">
                            <div className="sun">
                                <p></p>
                            </div>
                            <div className="mercury1"></div>
                            <div className="earth">
                                <div className="moon"></div>
                            </div>
                            <div className="mercury2"></div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    )
}
